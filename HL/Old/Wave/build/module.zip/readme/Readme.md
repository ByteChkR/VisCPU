# Wave Project
A simple Wave Animation with ASCII Characters.